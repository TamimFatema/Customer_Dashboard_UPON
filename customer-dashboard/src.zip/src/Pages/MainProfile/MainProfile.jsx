import React from "react";
import Sidebar from "../Sidebar/Sidebar";

const MainProfile = () => {
  return <Sidebar />;
};

export default MainProfile;
